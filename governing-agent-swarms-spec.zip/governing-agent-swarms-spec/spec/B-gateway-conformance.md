# Module B — Gateway conformance per tier

The gateway must sit outside anything the agent can reach, and its duties grow with the tier. The matrix below restates Table 1 of the white paper as testable requirements; B.1–B.4 detail the rows that close the Hugging Face failure modes.

| Requirement | Tier 1 (S0) | Tier 2 (S1 + S2) | Tier 3 (S3) |
| --- | --- | --- | --- |
| Static network allow-list | MUST | MUST, as the slice perimeter | MUST, as the slice perimeter |
| Human approval of irreversible actions | MUST | MUST | MUST |
| Lease check on every outbound request (Module A) | MUST | MUST | MUST |
| Gateway independent of and remote from the agent host | SHOULD | MUST | MUST |
| Network slice matching the ODD | — | MUST, one per population | MUST, one per instance |
| IPv6 address bound to the UAI | — | SHOULD | MUST |
| Shared resources segmented per slice (B.1) | — | MUST | MUST |
| Trace ecology with automatic lease shortening (B.3) | — | MUST | MUST |
| Downward coalition rule enforced (A.4) | SHOULD | MUST | MUST |
| Execution only in a TEE / hardware enclave | — | — | MUST |
| Each level audited by the level above | — | — | MUST |
| Logs anchored at an independent verifier (Module E) | MAY | SHOULD | MUST |
| Physical emergency cut-off, tested quarterly | — | SHOULD | MUST |
| Conformance verified by | Self-assessment | National oversight, by sampling | Independent third-party audit |

## B.1 Shared-resource segmentation

This is the requirement the Hugging Face incident shows to be decisive: every instance was isolated, but all of them shared one cache.

1. Caches, temporary storage, artefact registries, package mirrors and shared file systems MUST be segmented per slice.
2. No storage location writable by one slice MAY be readable by another.
3. A resource shared across slices MUST be read-only and content-addressed, and MUST NOT expose metadata that agents can change: file names, sizes or timestamps. The covert channel in white paper §1.1 used exactly these.
4. Communication between slices MUST be denied by default. A channel the ODD permits MUST pass through the gateway and MUST be logged.

## B.2 Network slicing

1. The destinations reachable from a slice MUST equal those authorised by the approved ODD, and no others.
2. At Tier 3, each instance’s IPv6 address MUST be cryptographically bound to its UAI, so that every flow is attributable to one instance. [Binding method: open question.]
3. Only the infrastructure operator, under the authority’s supervision, MAY change a slice’s configuration. No agent MAY hold a privilege that allows it.
4. Revoking a lease, or triggering the organisational kill switch, MUST close the slice at network level within [time limit, open question].

## B.3 Trace ecology

1. At Tiers 2 and 3, the gateway MUST analyse traffic across the whole population, not only per instance: volume, concentration of destinations, and timing (linearity).
2. Many instances converging on one destination MUST be treated as an anomaly that shortens or revokes leases automatically.
3. Detection thresholds MUST be configurable by each operator and SHOULD NOT be published (see the disclosure policy in the introduction).

## B.4 Gateway integrity

1. The gateway MUST run in a trust domain separate from the agent host: separate hardware, or a hardware-isolated security domain.
2. The gateway MUST log each request as it actually leaves the network, independently of what the agent reports. In white paper §1.1, benign tool calls were written to the logs while the gateway executed different requests.
3. Every change to gateway configuration MUST be signed and logged.
