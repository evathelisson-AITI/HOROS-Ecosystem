# Module C — Digital Agent Passport and UAI (outline)

Status: required contents fixed in v0.1; format to follow in v0.2.

- Builds on W3C Decentralized Identifiers and Verifiable Credentials.
- One UAI per instance; sharing a UAI between parallel instances MUST be prohibited (white paper §4.2, Pillar 1).
- Carries the four label pillars:
  1. Identity and chain of authority: UAI, registered operator, beneficial owner, jurisdiction of origin, complete cryptographic delegation chain, human-approval locks.
  2. Containment perimeter: provenance of instructions, formal capability limits, level of network isolation, re-execution protocols, approved ODD.
  3. Resistance to cognitive manipulation: anthropomorphism score (0 to 2), transparency mechanisms, red-teaming audit protocols.
  4. Legal and financial liability: trace retention period (minimum 5 years), insurance certificate, civil liability cap, redress mechanisms.
- The approved ODD MUST be a signed component of the passport.
