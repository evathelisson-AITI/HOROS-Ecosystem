# Module A — HOROS lease format

No agent action may reach a resource without a valid lease, and the gateway, not the agent, checks it. A lease is a short-lived signed object with the five elements of white paper §4.4. v0.1 proposes encoding it as a signed JSON object (JWS), mappable to a W3C Verifiable Credential.

## A.1 Fields

| Field | Content | Rule |
| --- | --- | --- |
| `lease_id` | Unique identifier of the lease | MUST be unique per issuer |
| `principal` | UAI of one instance (a W3C DID) | MUST name exactly one instance; the lease MUST NOT be transferable |
| `lineage` | Ordered delegation chain from the human operator to the instance | Each step MUST be signed by its delegator |
| `domain_of_effect` | Destinations, APIs, data sets and tools the instance may affect | MUST be a subset of the approved ODD |
| `odd_ref` | Hash of the approved ODD dossier and the authority’s signature | MUST match a dossier the verifier can retrieve |
| `not_before`, `expires` | Validity window | MUST NOT exceed the maximum for the tier: [value per tier, open question] |
| `anchor` | Issuing State or authority and its proof of legal compliance | MUST identify an authority recognised by the coalition |
| `signature` | Issuer’s signature over all fields | MUST verify against an accredited issuer key |

## A.2 Validation at the gateway

For every outbound request, the gateway MUST check, in this order:

1. The signature verifies and the issuer is accredited.
2. The current time is inside the validity window.
3. The requester is authenticated as the `principal`; a lease presented by any other instance MUST be refused.
4. Every lineage step is signed, and each child’s domain is contained in its parent’s (A.4).
5. The requested destination and operation fall inside `domain_of_effect`.
6. The lease is not revoked, using a revocation status no older than [interval, open question].

If any check fails or cannot be completed, the gateway MUST block the request (fail closed) and MUST log the decision to Module E. White paper §5.2: block first, preserve evidence second.

## A.3 Revocation

- The operator, the competent authority and the operator’s audit committee MUST each be able to revoke a single lease or all leases of the operator at once (the organisational kill switch, §4.6.3).
- Revoking a lease MUST close the corresponding slice at network level (§4.3).
- Suspending the entity licence MUST revoke every lease issued under it (§4.5).

## A.4 Downward coalition rule

A child agent’s authority is always the intersection of its parent’s authority and its own task, so the domain of effect can only shrink along the lineage:

```math
D_{\text{child}} = D_{\text{parent}} \cap T_{\text{child}}, \qquad D_{\text{child}} \subseteq D_{\text{parent}} \subseteq \text{ODD}
```

## A.5 Illustrative lease (non-normative)

```json
{
  "lease_id": "urn:horos:lease:7f3c…",
  "principal": "did:example:uai:instance-0042",
  "lineage": [
    {"from": "did:example:operator:alice-co", "to": "did:example:uai:bob", "sig": "…"},
    {"from": "did:example:uai:bob", "to": "did:example:uai:instance-0042", "sig": "…"}
  ],
  "domain_of_effect": ["api.example-lab.internal/eval/*"],
  "odd_ref": {"hash": "sha256:…", "authority_sig": "…"},
  "not_before": "2026-11-02T10:00:00Z",
  "expires": "[per tier]",
  "anchor": {"authority": "[national AI Safety Institute]", "proof": "…"},
  "signature": "…"
}
```
