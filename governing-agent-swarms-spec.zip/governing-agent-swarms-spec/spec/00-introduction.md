# Introduction: scope, terms and disclosure policy

## 1. Status and scope

Version 0.1 turns the white paper’s Tiered Containment Architecture and HOROS protocol into requirements that an implementer can build and a verifier can test. It is a working draft for public comment, not a standard.

| Item | v0.1 position |
| --- | --- |
| Source | White paper *Governing Agent Swarms*, 19 October 2026, §4.2–4.6 |
| Specified in full | Module A (HOROS lease) and Module B (gateway conformance per tier) |
| Outlined only | Modules C–E (Passport and UAI, ODD dossier, audit log and registry) |
| Out of scope | The Convention text, licensing procedure and corporate governance: legal instruments, not technical ones |
| Licences | Specification text: CC BY 4.0. Code: Apache 2.0 |
| Comment period | [start date] to [end date] |

## 2. Conventions and terms

The key words MUST, MUST NOT, SHOULD, SHOULD NOT and MAY are used as defined in [RFC 2119](https://www.rfc-editor.org/rfc/rfc2119) and [RFC 8174](https://www.rfc-editor.org/rfc/rfc8174), and only when written in capitals. Every MUST in this specification is meant to be testable by a third party.

| Term | Definition |
| --- | --- |
| Agent instance | One running copy of a model with its own execution context. Parallel copies of the same model are separate instances. |
| Agent population | The set of instances an operator runs under one approved ODD. |
| Operator | The legal entity that runs the instances and holds the entity licence. |
| UAI | Unique Agent Identifier: one per instance, never shared between instances (white paper §4.2, Pillar 1). |
| ODD | Operational Design Domain: the resources, tools, instance count, inter-instance channels, jurisdictions and stop conditions approved in advance by the competent authority (§4.2). |
| HOROS lease | A short-lived signed authorization binding one instance’s actions to a delegation chain, a domain of effect and an issuing authority (§4.4). |
| Gateway | The enforcement point outside the agent’s reach that checks leases and controls traffic. Called the Containment Gateway or Egress Gateway in the white paper. |
| Slice | A logically isolated IPv6/SRv6 network segment whose reachable destinations equal the approved ODD (§4.3). |
| Verifier | An accredited independent verification organisation that anchors audit logs (Truebit-type). |
| Trace ecology | Analysis of traffic patterns across a population: volume, destinations, linearity (§4.3, S2). |

## 3. Modules and disclosure policy

Five modules form one chain: the authority approves the ODD (D), the passport carries it (C), leases are issued within it (A), the gateway enforces them (B), and the audit log proves what happened (E). The agent holds no key to any part of this chain: every check runs at the gateway, outside its reach.

**Disclosure policy.** The barriers are designed to work even when the agent knows exactly how they work (Kerckhoffs’s principle), so they are published in full.

| Published in full | Set by each operator, not published |
| --- | --- |
| Lease format and validation rules (Module A) | Trace-ecology detection thresholds (B.3) |
| Gateway requirements per tier (Module B) | Anomaly heuristics and their tuning |
| Passport, ODD dossier and audit log formats (Modules C–E) | Internal network addressing plans |
| Conformance tests | |

Thresholds stay private for a specific reason: frontier models learn from public text, and a published threshold is one an agent swarm could learn to stay under.
