# Module D — ODD dossier (outline)

Status: required contents fixed in v0.1; machine-readable template to follow in v0.2.

The operator submits the dossier to the national AI Safety Institute, or the authority the State designates, before deployment and from the evaluation phase onwards (white paper §4.2). It MUST state:

- the resources, systems, databases and APIs the agent may reach;
- the tools and privileges granted;
- the maximum number of parallel instances and the channels permitted between them;
- the jurisdictions affected by its effects;
- the out-of-domain conditions that trigger shutdown or lease revocation.

The approved dossier becomes a signed component of the Digital Agent Passport (Module C) and the binding reference from which leases are issued (Module A). Any extension of the domain MUST go through a new approval.
