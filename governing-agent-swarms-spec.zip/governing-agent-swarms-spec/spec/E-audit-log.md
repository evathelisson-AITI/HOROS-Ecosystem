# Module E — Audit log and registry (outline)

Status: required contents fixed in v0.1; record format to follow in v0.2.

- One record per gateway decision: time, `lease_id`, `principal`, destination, operation, decision (allow or block), and a hash of the request as executed.
- Records MUST be hash-chained, so that any deletion or alteration is detectable.
- The chain MUST be anchored periodically with at least one accredited verifier, and SHOULD be anchored with several, including at least one established in the EU (white paper §4.3, §4.6.2).
- Retention MUST be at least 5 years (§4.2, Pillar 4).
- An attempt to alter or falsify traces MUST itself be recorded as an event: under §5.2 it constitutes a material violation.
