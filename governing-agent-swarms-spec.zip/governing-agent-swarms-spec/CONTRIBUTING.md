# Contributing

Thank you for helping improve this specification. During the v0.1 comment period, comments matter more than polished text.

## Ways to contribute

1. **Comment on a requirement.** Open an issue with the *Spec comment* template. Quote the requirement number (for example `A.2.3`) and say what you would change and why.
2. **Answer an open question.** Reply in the matching `open-question` issue (see [OPEN-QUESTIONS.md](OPEN-QUESTIONS.md)).
3. **Propose text.** Open a pull request against `main`. Keep one topic per pull request and reference the issue it addresses.
4. **Contribute test code.** Harnesses for tests T1–T7 go under `tests/`, licensed under Apache 2.0.

## Writing rules

- Use MUST, SHOULD and MAY (RFC 2119 / RFC 8174) only for requirements, in capitals.
- Every MUST should be testable by a third party. If you cannot say how to test it, propose a SHOULD or open a question instead.
- Cite the white paper section a requirement comes from, where there is one.
- Do not propose publishing detection thresholds or anomaly heuristics (see the disclosure policy in `spec/00-introduction.md`).

## Sign-off (Developer Certificate of Origin)

Every commit must be signed off to certify that you have the right to submit it under the repository’s licences, as described at <https://developercertificate.org/>:

```
git commit -s -m "Clarify A.2 check order"
```

This adds a `Signed-off-by: Your Name <you@example.org>` line to the commit.

## Licences of contributions

- Contributions to `spec/` and other text are licensed under CC BY 4.0.
- Contributions of code are licensed under Apache 2.0.

## Conduct

Be precise, be courteous, and argue about requirements, not people. Maintainers may close comments that are off topic or abusive.
