---
name: Spec comment
about: Comment on a specific requirement of the specification
title: "[A.2.3] Short summary of your comment"
labels: ["spec-comment", "v0.1"]
---

**Requirement:** <!-- e.g. A.2.3, B.1.2 -->

**Current text:**
<!-- quote the requirement -->

**Problem:**
<!-- what is unclear, untestable, too strict or too weak -->

**Proposed change:**
<!-- your wording, or the direction you suggest -->

**Your context (optional):**
<!-- lab, operator, regulator, researcher, implementer -->
