# Changelog

## v0.1 — [YYYY-MM-DD]

First public draft for comment.

- Module A (HOROS lease format) and Module B (gateway conformance per tier) specified in full.
- Modules C (Digital Agent Passport), D (ODD dossier) and E (audit log) outlined.
- Conformance tests T1–T7 defined from the 2026 Hugging Face incident.
- Eight open questions published for reviewers.
