# Open questions for v0.1 reviewers

Each question below should be opened as its own GitHub issue, labelled `open-question` and `v0.1`. The bracketed values in the specification depend on the answers.

## OQ-1 Maximum lease duration per tier
**Where:** A.1 (`not_before`, `expires`).
A lease must be short enough to prevent uncontrolled persistence, and long enough not to overload issuers. What maximum validity should apply at Tier 1, Tier 2 and Tier 3?

## OQ-2 Freshness of revocation status
**Where:** A.2, check 6.
How old may the revocation status used by the gateway be? Should the gateway pull a list, receive pushes, or check each lease online?

## OQ-3 Time limits for slice closure, lease shortening and the kill switch
**Where:** B.2.4, B.3, tests T4 and T7.
What maximum delay should apply between a trigger (revocation, anomaly, kill switch) and the effect at network level?

## OQ-4 Binding an IPv6 address to a UAI
**Where:** B.2.2.
How should an instance’s address be cryptographically bound to its UAI? Cryptographically Generated Addresses (RFC 3972) are one candidate. What are the alternatives, and what do they cost at scale?

## OQ-5 Lease encoding
**Where:** A (introduction).
JWS, W3C Verifiable Credential 2.0, or CBOR/COSE for constrained links? Criteria: interoperability, verification speed, tooling.

## OQ-6 Proportionality at Tier 1
**Where:** Module B matrix, row “Lease check on every outbound request”.
Should Tier 1 require a lease check on every request, or only on irreversible actions?

## OQ-7 Permitted channels between instances
**Where:** B.1.4, Module D.
How is a channel between instances that the ODD permits declared, inspected and logged, including agent protocols such as MCP?

## OQ-8 Gateway behaviour when no verifier is reachable
**Where:** Module E.
Should the gateway block all traffic, or buffer records and anchor them later? What is the maximum buffering time?
