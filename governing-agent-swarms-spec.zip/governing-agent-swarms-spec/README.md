# Governing Agent Swarms — Technical Specification

**Version 0.1 · Draft for public comment** · Comment period: [start date] to [end date]

This specification turns the Tiered Containment Architecture and the HOROS protocol from the white paper *Governing Agent Swarms: From the 2026 Incident to Innovative Guardrails* (E. Thelisson, AI Transparency Institute, AI Safety Days, ETH Zurich, 19 October 2026) into requirements that an implementer can build and a third party can test.

It starts from one lesson of the 2026 Hugging Face incident: every agent was isolated, but they all shared one cache, and that was enough to coordinate 1,200 instances. Safety therefore has to rest on external barriers the agent can neither modify nor bypass.

## The five modules

```mermaid
flowchart LR
    D["D · ODD dossier<br/>approved by the authority"] --> C["C · Agent Passport<br/>UAI + signed ODD"]
    C --> A["A · HOROS lease<br/>short-lived, within the ODD"]
    A -- "checked on every request" --> B
    I["Agent instance<br/>one UAI, its own slice"] --> B["B · Gateway<br/>checks lease, enforces slice"]
    B --> R["Resources in the ODD<br/>the only reachable ones"]
    B -- "every decision" --> E["E · Audit log<br/>hash-chained decisions"]
    E --> V["Independent verifier<br/>anchors the log"]
```

| Module | File | v0.1 status |
| --- | --- | --- |
| Introduction: scope, terms, disclosure policy | [spec/00-introduction.md](spec/00-introduction.md) | Full |
| A. HOROS lease format | [spec/A-horos-lease.md](spec/A-horos-lease.md) | Full |
| B. Gateway conformance per tier | [spec/B-gateway-conformance.md](spec/B-gateway-conformance.md) | Full |
| C. Digital Agent Passport and UAI | [spec/C-agent-passport.md](spec/C-agent-passport.md) | Outline |
| D. ODD dossier | [spec/D-odd-dossier.md](spec/D-odd-dossier.md) | Outline |
| E. Audit log and registry | [spec/E-audit-log.md](spec/E-audit-log.md) | Outline |
| Conformance tests (Hugging Face scenario) | [tests/README.md](tests/README.md) | Test definitions |

## How to comment

- **On a specific requirement:** open an issue with the *Spec comment* template and quote the requirement (for example `B.1.3`).
- **On an open question:** reply in its issue, labelled `open-question`. The list is in [OPEN-QUESTIONS.md](OPEN-QUESTIONS.md).
- **Broader discussion:** use GitHub Discussions.
- **Proposed text changes:** pull requests are welcome; see [CONTRIBUTING.md](CONTRIBUTING.md).

## Roadmap

1. **v0.1:** public comment period on this draft.
2. **v0.2:** formats for Modules C–E, and first results of tests T1–T7 on a test bed.
3. **v0.3:** a Tier 2 pilot with a lab, a network operator and a national AI Safety Institute.
4. **v1.0:** modules submitted to W3C (identity), IETF (lease and network slicing) and CEN-CENELEC JTC 21 (AI Act standards).

## Licence

- Specification text: [Creative Commons Attribution 4.0 International (CC BY 4.0)](LICENSE).
- Code in this repository, when added: [Apache License 2.0](LICENSE-CODE).

## Citation

See [CITATION.cff](CITATION.cff). Each release is archived on Zenodo with its own DOI: [DOI to add after first release].

## Mirror

Mirrored at [Codeberg link]. The Zenodo archive is the reference copy.
